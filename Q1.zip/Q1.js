let url = "https://kontests.net/api/v1/all"
let a = fetch(url)
a.then((value)=>{
   return value.json()
}).then((value1)=>{
    console.log(value1)
    ihtml = ""
    for(item in value1 ){
        console.log(value1[item])
        ihtml += `
        <div   class="card" style="width: 18rem; background-color: "voilet"; colo">
        <img class="cards" src="https://csharpcorner-mindcrackerinc.netdna-ssl.com/article/what-is-competitive-programming-and-why-it-is-importantcontests/Images/Top-10-Programming-Languages-to-Watch-Out-in-2019.png"
            class="card-img-top" alt="...">
        <div class="card-body">
            <h5 class="card-title">${value1[item].name}</h5>
            <p> Starts at : ${value1[item].start_time}</p>
            <p> Ends at : ${value1[item].end_time}</p>
            
            <p> Duration : ${value1[item].duration}</p>
            <p> Site : ${value1[item].site}</p>
            <p> in_24_hours : ${value1[item].in_24_hours}</p>
            <p> Status : ${value1[item].status}</p>
            <a id = "q" href="${value1[item].url}" class="btn btn-primary">Visit contest</a>
        </div>
        </div>
        `
    }
    CardContainer.innerHTML = ihtml
})
